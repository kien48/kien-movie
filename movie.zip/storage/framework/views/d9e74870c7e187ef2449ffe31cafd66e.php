<?php $__env->startSection('content'); ?>
    <div >
        <h1 class="text-center h3">Cập nhật phim</h1>
        <div >
            <form action="<?php echo e(route('admin.movies.update',$modelMovie['slug'])); ?>" method="post" name="form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card">
                    <h4>Thông tin phim</h4>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mt-3">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="mb-3  col-6">
                            <label for="ten" class="form-label">Tên phim:</label>
                            <input type="text" class="form-control" id="ten" name="ten" value="<?php echo e($modelMovie['ten']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Danh sách:</label>
                            <select type="text" class="form-control" name="list_id">
                                <option value="">Chọn</option>
                                <?php $__currentLoopData = $dataLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if($item->id == $modelMovie['list_id']): ?> selected <?php endif; ?>><?php echo e($item->ten); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Link ảnh:</label>
                            <input type="text" class="form-control" name="anh" value="<?php echo e($modelMovie['anh']); ?>" >
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Ngôn ngữ:</label>
                            <input type="text" class="form-control" name="ngon_ngu" value="<?php echo e($modelMovie['ngon_ngu']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Giá phim:</label>
                            <input type="text" ng-model="gia" class="form-control" name="gia" value="<?php echo e($modelMovie['gia']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Số tập:</label>
                            <input type="number" class="form-control" name="so_tap" value="<?php echo e($modelMovie['so_tap']); ?>" >
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Chất lượng:</label>
                            <input type="text" class="form-control" name="chat_luong" value="<?php echo e($modelMovie['chat_luong']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Đạo diễn:</label>
                            <input type="text" class="form-control" name="dao_dien" value="<?php echo e($modelMovie['dao_dien']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Diễn viên:</label>
                            <input type="text" class="form-control" name="dien_vien" value="<?php echo e($modelMovie['dien_vien']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Năm phát hành:</label>
                            <input type="text" class="form-control" name="nam_phat_hanh" value="<?php echo e($modelMovie['nam_phat_hanh']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Quốc gia:</label>
                            <input type="text" class="form-control" name="quoc_gia" value="<?php echo e($modelMovie['quoc_gia']); ?>">
                        </div>
                        <div class="mb-3 col-6">
                            <label for="pwd" class="form-label">Mô tả:</label>
                            <textarea class="form-control" name="mo_ta"><?php echo e($modelMovie['mo_ta']); ?></textarea>
                        </div>
                        <div class="mb-3 col-6">
                            <input class="form-check-input" type="checkbox" id="mySwitch" name="is_vip"  value="1" ng-model="isVip" ng-change="updateGia()" >
                            <label class="form-check-label" for="mySwitch">Phải vip không?</label>
                        </div>
                    </div>

                </div>
                <div class="card mt-3">
                    <h4>Thể loại</h4>
                    <div class="mb-3">
                        <select type="text" class="form-control" name="catelogue_id[]" multiple>
                            <?php $__currentLoopData = $dataCatelogues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $status = '';
                                    foreach($modelCatelogue as $cate) {
                                        if($item->id == $cate['id']) {
                                            $status = 'selected';
                                            break; // Break out of the loop once a match is found
                                        }
                                    }
                                ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($status); ?>><?php echo e($item->ten); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="card mt-3 mb-3">
                    <div class="d-flex justify-content-between">
                        <h4>Tập</h4>
                        <button type="button" class="btn btn-danger" ng-show="<?php echo e(count($modelEpisode)); ?> ==0 " ng-click="addEpisode()">Thêm tập</button>
                        <button type="button" class="btn btn-danger" ng-show="<?php echo e(count($modelEpisode)); ?> > 0 " ng-click="addTap()">Thêm tập</button>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Tập</th>
                            <th>Link</th>
                            <th>Hành động</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr ng-show="<?php echo e(count($modelEpisode)); ?> ==0 " ng-repeat="episode in episodes">
                            <td><input type="number" class="form-control" name="tap_phim[{{ episode.number }}-{{ episode.link }}][so]" ng-model="episode.number"></td>
                            <td><input type="text" class="form-control" name="tap_phim[{{ episode.number }}-{{ episode.link }}][link]" ng-model="episode.link"></td>
                            <td><button type="button" class="btn btn-danger" ng-click="removeEpisode($index)">Xóa</button></td>
                        </tr>
                        <tr ng-repeat="episode in dsTap">
                            <td><input type="number" class="form-control" name="tap_phim[{{ episode.tap }}-{{ episode.link }}][so]" ng-model="episode.tap"></td>
                            <td><input type="text" class="form-control" name="tap_phim[{{ episode.tap }}-{{ episode.link }}][link]" ng-model="episode.link"></td>
                            <td><button type="button" class="btn btn-danger" ng-click="removeTap($index)">Xóa</button></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <button class="btn btn-success mb-4 mt-4"  ng-disabled="form.$invalid">Gửi</button>
            </form>

        </div>
    </div>
    <?php $__env->startSection('js'); ?>
        <script>
            viewFunction = ($scope,$http)=>{
                $scope.dsTap = []
                $http.get('http://movie.test/api/episode/<?php echo e($modelMovie['slug']); ?>')
                    .then(function (res){
                        $scope.dsTap = res.data.data
                        console.log($scope.dsTap)
                        }
                    )
                $scope.addTap = function() {
                    $scope.dsTap.push({ tap: $scope.dsTap.length + 1, link: '' });
                };
                $scope.removeTap = function(index) {
                    $scope.dsTap.splice(index, 1);
                };

                $scope.episodes = [{ number: 1, link: '' }];
                console.log($scope.episodes)
                $scope.addEpisode = function() {
                    $scope.episodes.push({ number: $scope.episodes.length + 1, link: '' });
                };

                $scope.removeEpisode = function(index) {
                    $scope.episodes.splice(index, 1);
                };

                $scope.isVip = <?php if($modelMovie['is_vip'] == 1): ?> true <?php else: ?> false <?php endif; ?>;
                $scope.gia = <?php echo e($modelMovie['gia']); ?>;
                $scope.updateGia = function() {
                    if ($scope.isVip) {
                        $scope.gia = 0;
                    } else {
                        $scope.gia = <?php echo e($modelMovie['gia']); ?>;
                    }
                };

            }
        </script>
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/admin/movies/edit.blade.php ENDPATH**/ ?>
