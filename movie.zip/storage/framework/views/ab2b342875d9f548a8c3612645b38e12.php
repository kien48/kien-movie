<?php $__env->startSection('title'); ?>
    Cập nhật tài khoản
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <div class="card mt-4">
            <div class="card-header">
                Cập nhật tài khoản
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('updatetk')); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($e); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php if(session('success')): ?>
                        <li><?php echo e(session('success')); ?></li>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="amount">Tên bạn:</label>
                        <input type="text" name="ten" class="form-control" ng-model="ten" ng-change="check()" placeholder="Điền tên của bạn">
                        <span ng-show="thongBaoTen == false" class="text-danger h5">Không để trống!</span>
                    </div>
                    <div class="form-group">
                        <label for="amount">Email:</label>
                        <input type="Email" name="email" class="form-control"  ng-model="email" ng-change="check()" placeholder="Điền email của bạn">
                        <span ng-show="thongBaoEmail == false" class="text-danger h5">Không để trống!</span>
                    </div>
                    <button type="submit" name="redirect" class="btn btn-danger mt-3 btn-block" ng-disabled="disableButton">Gửi</button>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
        <script>
            viewFunction = ($scope,$http)=>     {
                $scope.ten = '<?php echo e(Auth::user()->name); ?>';
                $scope.email = '<?php echo e(Auth::user()->email); ?>';
                $scope.disableButton = true;
                $scope.thongBaoTen = true;
                $scope.thongBaoEmail = true;
                $scope.check = function() {
                    $scope.disableButton = ($scope.ten == "" || $scope.email == "");
                    $scope.thongBaoTen = ($scope.ten != "");
                    $scope.thongBaoEmail = ($scope.email != "");
                };
            }
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/auth/edit.blade.php ENDPATH**/ ?>