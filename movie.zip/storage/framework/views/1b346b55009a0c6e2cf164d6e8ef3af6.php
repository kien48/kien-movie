<?php $__env->startSection('content'); ?>
    <div>
        <h1 class="text-center h3">Cập nhật bài viết</h1>
        <form action="<?php echo e(route('admin.posts.update',$model[0]['id'])); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div class="row">
                <div class="mt-3 col-6">
                    <label class="form-label">Tiêu đề</label>
                    <input type="text" name="tieu_de" id="" class="form-control" value="<?php echo e($model[0]['tieu_de']); ?>">
                </div>
                <div class="mt-3 col-6">
                    <label class="form-label">Ảnh</label>
                    <input type="file" name="anh" id="" class="form-control">
                    <img src="<?php echo e($model[0]['anh']); ?>" alt="" width="100px">
                </div>
                <div class="mt-3 col-6">
                    <label class="form-label">Danh mục: </label>
                    <select type="text" name="catelogue_post_id" id="" class="form-select">
                        <option>Chọn danh mục</option>
                        <?php $__currentLoopData = $dataCateloguePost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cate->id); ?>" <?php if($model[0]['catelogue_post_id'] == $cate->id): ?> selected <?php endif; ?>><?php echo e($cate->ten); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mt-3 col-6">
                    <label class="form-label">Tag: </label>
                    <select type="text" name="tag[]" id="" class="form-select" multiple>
                        <?php $__currentLoopData = $dataTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $model[0]['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $status = "";
                                     if($tag->id == $tagP['id']){
                                         $status = "selected";
                                         break;
                                     }
                                    ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tag->id); ?>" <?php echo e($status); ?>><?php echo e($tag->ten); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="mt-3 col-6">
                    <label class="form-label">Nội dung: </label>
                    <textarea name="noi_dung"><?php echo e($model[0]['noi_dung']); ?></textarea>
                </div>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-success">Gửi</button>
            </div>

        </form>
    </div>
    <?php $__env->startSection('js'); ?>
        <script src="https:////cdn.ckeditor.com/4.8.0/basic/ckeditor.js"></script>
        <script>
            CKEDITOR.replace( 'noi_dung' );
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>
