<?php $__env->startSection('title'); ?>
    <?php echo e($model->tieu_de); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-post'); ?>
    <h1 class="text-warning" id="demThoiGian"></h1>
    <h1 class="text-danger"><?php echo e($model->tieu_de); ?></h1>
    <div class="d-flex mt-3 mb-2  justify-content-between">
        <div>
          <h4>Người đăng: <?php echo e($model->user->name); ?></h4>
        </div>
        <div>
            <h4>Đăng ngày: <?php echo e($model->created_at); ?></h4>
        </div>
    </div>
    <div class="mb-4">
        <h4>Lượt xem: {{ luotxem }}</h4>
    </div>
    <?php
        $text = htmlspecialchars($model->noi_dung);
        $text = html_entity_decode($text);
        echo $text;
        ?>
    <div class="box">
        <h3>Danh mục bài viết</h3>
        <div class="categories">
                <a href="<?php echo e(route('danhMucBaiViet',[$cate['id'],$cate['slug']])); ?>"><?php echo e($cate['ten']); ?></a>
        </div>
    </div>
    <div class="box">
        <h3>Tags bài viết</h3>
        <div class="tags">
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <a href="<?php echo e(route('tagBaiViet',[$item['id'],$item['slug']])); ?>"><?php echo e($item['ten']); ?></a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
        <script>
            var viewFunction = function ($scope, $http) {
                var setThoiGian = 10;
                $scope.themLuotXem = () =>{
                   $http.post('<?php echo e(route('themLuotXem')); ?>',{
                       id : <?php echo e($model['id']); ?>

                   }).then(function (res){
                       $scope.loadLuotXem()
                   }).catch(function (error){
                       console.log(error)
                   })
                }
                $scope.luotxem = 0;
                $scope.loadLuotXem = ()=>{
                    $http.get('http://movie.test/api/luot-xem-bai-viet/<?php echo e($model['id']); ?>')
                        .then(function (res){
                            $scope.luotxem = res.data.data
                            console.log($scope.luotxem)
                        }).catch(function (error){
                        console.log(error)
                    })
                }
                $scope.loadLuotXem()
                setInterval($scope.loadLuotXem,5000)
                var demNguoc = setInterval(function() {
                    setThoiGian--;
                    if (setThoiGian <= 0) {
                        clearInterval(demNguoc);
                        $scope.themLuotXem()
                    }
                }, 1000);
            }
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('blogs.blogs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/blogs/detail.blade.php ENDPATH**/ ?>