<?php $__env->startSection('title'); ?>
    Tài khoản
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .btn-custom {
            border-radius: 0;
            background-color: #e50914;
            border-color: #e50914;
        }

        .card {
            background-color: #333333;
            border: none;
        }

        .card-header {
            background-color: #444444;
        }

        .info-item {
            margin-bottom: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card mt-4">
                    <div class="card-header text-white">
                        Thông Tin Tài Khoản
                    </div>
                    <div class="card-body">
                        <p class="info-item text-white mt-3" ><strong>Số
                                Xu:</strong> <?php echo e(isset($data['coin'][0]['coin']) ? number_format($data['coin'][0]['coin']) : 0); ?>

                            xu <a href="<?php echo e(route('transactions')); ?>">Lịch sử giao dịch</a></p>
                        <p class="info-item text-white mt-3"><strong>Hạng Thành Viên:</strong> <?php if($data['is_vip'] ==1): ?> VIP <?php else: ?> Thường <?php endif; ?></p>
                        <a href="<?php echo e(route('napXu')); ?>" class="btn btn-outline-primary mt-3 w-100 btn-lg">Nạp xu</a>
                        <a href="<?php echo e(route('purchasedMovies')); ?>" class="btn btn-outline-success mt-3 w-100 btn-lg">Phim đã
                            mua</a>
                        <a href="<?php echo e(route('capnhattk')); ?>" class="btn btn-outline-warning mt-3 w-100 btn-lg">Cập nhật tài khoản</a>
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
                           class="btn btn-outline-danger mt-3 w-100 btn-lg">Đăng xuất</a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/auth/home.blade.php ENDPATH**/ ?>