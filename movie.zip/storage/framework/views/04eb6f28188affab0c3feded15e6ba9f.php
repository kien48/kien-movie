<?php $__env->startSection('title'); ?>
    Nạp xu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <div class="card mt-4">
            <div class="card-header">
                Thất bại
            </div>
            <div class="card-body">
                <h3>Thanh toán thất bại</h3>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('home')); ?>" class="btn btn-danger">Về trang chủ</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/auth/error.blade.php ENDPATH**/ ?>