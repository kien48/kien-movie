<?php $__env->startSection('title'); ?>
    Phim đã mua
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container movie-section" style="margin-top: 100px;">
        <div class="row mb-5">
            <div class="col mb-1">
                <div id="" class="d-flex justify-content-between">
                    <h2>Phim đã mua</h2>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 movie-card mb-3 mt-3">
                            <a href="<?php echo e(route('detail', $item['slug'])); ?>" class="nav-link position-relative"
                               data-bs-toggle="tooltip" title="<?php echo e($item['ten']); ?>">
                                <img src="<?php echo e($item['anh']); ?>" alt="" class="img-fluid" width="200px">
                                    <span class="badge bg-success rounded-pill position-absolute top-0 end-0">
                                     Mua giá: <?php echo e(number_format($item['xu'])); ?> xu <br>
                                        Mua ngày: <?php echo e(\Carbon\Carbon::parse($item['created_at'])->format('d/m/Y H')); ?>h<br>
                                    </span>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/auth/movies.blade.php ENDPATH**/ ?>