<?php $__env->startSection('title'); ?>
    Chi tiết phim
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container movie-section" style="margin-top: 100px;">
        <div class="row">
            <div class="col-3 position-relative">
                <img src="<?php echo e($model['anh']); ?>" alt="" class="img-fluid"
                     style="border-radius: 10px;width: 290px;height: 450px">
                <?php if($model['gia'] >= 1): ?>
                    <span class="badge bg-danger rounded-pill position-absolute top-0 end-0">
                                     <i class="fa-solid fa-crown"></i>
                        <span ng-show="statusMuaPhim == true">Đã mua</span>
                        <span ng-show="statusMuaPhim == false">Có phí</span>

                                    </span>
                <?php elseif($model['is_vip'] == true): ?>
                    <span class="badge bg-warning rounded-pill position-absolute top-0 end-0">
                                     <i class="fa-solid fa-crown"></i> Vip
                                    </span>
                <?php endif; ?>
            </div>
            <div class="col-9">
                <h3 class="mb-3"
                    style="font-weight: 700;font-size: 50px;<?php if($model['gia'] >= 1): ?> color:red <?php elseif($model['is_vip'] == true): ?> color:#fffa06 <?php else: ?> color:white <?php endif; ?>"><?php echo e($model['ten']); ?> </h3>
                <h5 class="font-monospace text-light-emphasis mt-3"><?php echo e($model['chat_luong']); ?>

                    ● <?php echo e($model['ngon_ngu']); ?> </h5>
                <h5 class="font-monospace text-light-emphasis mt-3">Số tập: <?php echo e($model['so_tap']); ?> | Hiện
                    tại: <?php echo e($model['trang_thai']); ?> </h5>
                <h5 class="font-monospace text-light-emphasis mt-3">Năm phát hành: <?php echo e($model['nam_phat_hanh']); ?>

                    <h5 class="font-monospace text-light-emphasis mt-3">Thể loại:
                        <?php if(count($model['catelogue']) >=1): ?>
                            <?php $__currentLoopData = $model['catelogue']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                | <?php echo e($data['ten']); ?> |
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            Đang cập nhật
                        <?php endif; ?>
                    </h5>
                    <h5 class="h4 mt-3" data-bs-toggle="tooltip"
                        title="<?php echo e($model['mo_ta']); ?>!"><?php echo e(substr($model['mo_ta'],0,200)); ?>... </h5>
                        <div class="d-flex mt-3">
                            <h5 class="font-monospace text-light-emphasis">Diễn viên:</h5>
                            <h5> <?php echo e($model['dien_vien']); ?> </h5>
                        </div>
                        <div class="d-flex mt-3">
                            <h5 class="font-monospace text-light-emphasis">Đạo diễn:</h5>
                            <h5> <?php echo e($model['dao_dien']); ?> </h5>
                        </div>
                        <div class="d-flex">
                            <?php if($model['is_vip'] == 0): ?>
                                <div class="d-flex mt-3">
                                    <h5 class="font-monospace text-light-emphasis">Giá phim:</h5>
                                    <h5> <?php echo e(number_format($model['gia'])); ?> xu </h5>
                                </div>
                            <?php endif; ?>
                            <div class="d-flex mt-3 ms-3">
                                <h5 class="font-monospace text-light-emphasis">Lượt thích:</h5>
                                <h5> {{ countLike }} </h5>
                            </div>
                        </div>
                        <div class="d-flex mt-2">
                            <?php if($is_vip == 0 && $model['is_vip'] == true): ?>
                                <div class="mt-3">
                                    <button class="btn btn-outline-warning"
                                            style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center;"
                                            disabled>
                                        <h4 style="margin: 0; display: flex; align-items: center;color: white;">
                                            Chỉ dành cho tài khoản VIP
                                        </h4>
                                    </button>
                                </div>
                            <?php else: ?>
                                <?php if(isset($model['episode'][0])): ?>
                                    <?php if($model['gia'] == 0): ?>
                                        <div class="mt-3">
                                            <a href="<?php echo e(route('watch', ['slug' => $model['slug'], 'tap' => $model['episode'][0]['tap']])); ?>"
                                               class="btn btn-light"
                                               style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                                <h2 style="margin: 0; display: flex; align-items: center;color: black;">
                                                    <i class="fa-solid fa-play" style="margin-right: 10px;"></i>
                                                </h2>
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <div class="mt-3" ng-show="statusMuaPhim == false">
                                            <button data-bs-toggle="modal" data-bs-target="#myModalMuaPhim"
                                                    class="btn btn-outline-warning"
                                                    style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                                <h2 style="margin: 0; display: flex; align-items: center;color: white;">
                                                    <i class="fa-solid fa-bag-shopping"
                                                       style="margin-right: 10px;"></i>
                                                </h2>
                                            </button>
                                        </div>
                                        <div class="mt-3" ng-show="statusMuaPhim == true">
                                            <a href="<?php echo e(route('watch', ['slug' => $model['slug'], 'tap' => $model['episode'][0]['tap']])); ?>"
                                               class="btn btn-light"
                                               style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                                <h2 style="margin: 0; display: flex; align-items: center;color: black;">
                                                    <i class="fa-solid fa-play" style="margin-right: 10px;"></i>
                                                </h2>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="mt-3">
                                        <a href="#" class="btn btn-warning"
                                           style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                            <h2 style="margin: 0; display: flex; align-items: center;color: white;">
                                                <i class="fa-solid fa-screwdriver-wrench"></i>
                                            </h2>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                            <div class="mt-3 ms-3" ng-show="ketqua === false">
                                <form action="" method="post">
                                    <button ng-click="add()" type="button" class="btn btn-outline-danger"
                                            style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                        <h2 style="margin: 0; display: flex; align-items: center;color: white;">
                                            <i class="fa-solid fa-heart"></i>
                                        </h2>
                                    </button>
                                </form>
                            </div>
                            <div class="mt-3 ms-3" ng-show="ketqua === true">
                                <form action="" method="post">
                                    <button ng-click="remove()" type="button" class="btn btn-danger"
                                            style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                        <h2 style="margin: 0; display: flex; align-items: center;color: white;">
                                            <i class="fa-solid fa-heart"></i>
                                        </h2>
                                    </button>
                                </form>
                            </div>

                            <?php if(Auth::check()): ?>
                                <div class="mt-3 ms-3">
                                    <form action="" method="post">
                                        <button ng-show="like == true" ng-click="unLike()" type="button"
                                                class="btn btn-info"
                                                style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                            <h2 style="margin: 0; display: flex; align-items: center;color: white;">
                                                <i class="fa-solid fa-thumbs-up"></i>
                                            </h2>
                                        </button>
                                    </form>
                                </div>
                                <div class="mt-3 ">
                                    <form action="" method="post">
                                        <button ng-show="like == false" ng-click="likes()" type="button"
                                                class="btn btn-outline-info"
                                                style="height: 80px; width: 170px; display: flex; align-items: center; justify-content: center; text-decoration: none;">
                                            <h2 style="margin: 0; display: flex; align-items: center;color: white;">
                                                <i class="fa-regular fa-thumbs-up"></i>
                                            </h2>
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
            </div>
        </div>
        <div class="row mb-5 mt-5">
            <div class="col mb-1">
                <div id="" class="d-flex justify-content-between">
                    <h2>Bạn có thể sẽ thích</h2>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $phimLienQuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 movie-card mb-3 mt-3">
                            <a href="<?php echo e(route('detail', $item['slug'])); ?>" class="nav-link position-relative"
                               data-bs-toggle="tooltip" title="<?php echo e($item['ten']); ?>">
                                <img src="<?php echo e($item['anh']); ?>" alt="" class="img-fluid" width="200px">
                                <?php if($item['gia'] >= 1): ?>
                                    <span class="badge bg-danger rounded-pill position-absolute top-0 end-0">
                                     <i class="fa-solid fa-crown"></i> Có phí
                                    </span>
                                <?php elseif($item['is_vip'] == true): ?>
                                    <span class="badge bg-warning rounded-pill position-absolute top-0 end-0">
                                     <i class="fa-solid fa-crown"></i> Vip
                                    </span>
                                <?php endif; ?>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- The Modal -->
    <div class="modal text-danger fade" id="myModalMuaPhim" tabindex="-1" aria-labelledby="myModalMuaPhimLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h3 class="modal-title text-white" id="myModalMuaPhimLabel">Mua phim</h3>
                    <button type="button" id="close" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if(isset($dataUser['coin'][0]['coin']) && $dataUser['coin'][0]['coin'] >= $model['gia']): ?>
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <h5 class="mb-3">Số xu còn
                                lại: <?php echo e(isset($dataUser['coin'][0]['coin']) ? number_format($dataUser['coin'][0]['coin']) : 0); ?>

                                xu</h5>
                            <h5 class="mb-3">Giá phim: <?php echo e(number_format($model['gia'])); ?> xu</h5>
                            <hr>
                            <h5 class="mb-3">Tổng xu còn
                                lại: <?php echo e(isset($dataUser['coin'][0]['coin']) ? number_format($dataUser['coin'][0]['coin'] - $model['gia']) : 0); ?>

                                xu</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" ng-click="muaPhim()" class="btn btn-primary">Xác nhận mua phim</button>
                    </form>
                    <?php else: ?>
                        <h3>Không đủ tiền để mua phim này</h3>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>

    <audio id="likeSound" src="<?php echo e(asset('/')); ?>/themes/web phim/public/img/click.mp3" preload="auto"></audio>
    <audio id="loveSound" src="<?php echo e(asset('/')); ?>/themes/web phim/public/img/love.mp3" preload="auto"></audio>

    <?php $__env->startSection('js'); ?>
        <script>
            viewFunction = ($scope, $http) => {
                // Thêm phim vào danh sách yêu thích
                $scope.add = function () {
                    $http.post('<?php echo e(route("add")); ?>', {
                        movie_id: '<?php echo e($model["id"]); ?>'
                    }).then(response => {
                        playLoveSound()
                        $scope.kiemTra();
                    }).catch(error => {
                        alert('Error');
                    });
                };

                // Xóa phim khỏi danh sách yêu thích
                $scope.remove = function () {
                    $http.post('<?php echo e(route("remove")); ?>', {
                        id: '<?php echo e($model["id"]); ?>'
                    }).then(response => {
                        $scope.kiemTra();
                    }).catch(error => {
                        alert('Error');
                    });
                };

                $scope.ketqua = false;

                $scope.kiemTra = () => {
                    $http.get('http://movie.test/api/favourite/<?php echo e($model['slug']); ?>')
                        .then(res => {
                            $scope.ketqua = res.data.status;
                        }).catch(error => {
                        console.error(error);
                    });
                };
                $scope.kiemTra();

                $scope.likes = () => {
                    $http.post('<?php echo e(route('likeMovie')); ?>', {
                        movie_id: '<?php echo e($model['id']); ?>'
                    }).then(function (res) {
                        $scope.checkLike();
                        $scope.countLikeMovie();
                        playLikeSound()
                    }).catch(error => {
                        console.error(error);
                    })
                }

                $scope.unLike = () => {
                    $http.post('<?php echo e(route('unLikeMovie')); ?>', {
                        movie_id: '<?php echo e($model["id"]); ?>',
                    }).then(function (res) {
                        $scope.checkLike();
                        $scope.countLikeMovie();
                    }).catch(error => {
                        console.error(error);
                    })
                }
                $scope.like = false;
                $scope.checkLike = () => {
                    $http.get('http://movie.test/api/like/<?php echo e($model['id']); ?>')
                        .then(function (res) {
                            $scope.like = res.data.status
                        })
                }
                $scope.checkLike();

                $scope.countLikeMovie = () => {
                    $http.get('http://movie.test/api/count-like/<?php echo e($model['id']); ?>')
                        .then(function (res) {
                            $scope.countLike = res.data.data;
                        }).catch(error => {
                        console.error(error);
                    });
                };

                $scope.countLikeMovie();
                setInterval($scope.countLikeMovie, 1000);


                $scope.muaPhim = () => {
                    $http.post('<?php echo e(route('muaPhim')); ?>', {
                        movie_id: <?php echo e($model['id']); ?>,
                        coin: <?php echo e($model['gia']); ?>

                    }).then(function (res) {
                        $scope.ttMuaPhim();
                        document.querySelector('.btn-close').click()
                        alert('Mua phim thành công');
                    })
                }
                $scope.statusMuaPhim = false;
                $scope.ttMuaPhim = () => {
                    $http.get('http://movie.test/api/mua-phim-status/<?php echo e($model['slug']); ?>')
                        .then(function (res) {
                            $scope.statusMuaPhim = res.data.status
                        }).catch(function (error) {
                        console.log(error)
                    })
                }
                $scope.ttMuaPhim();
                function playLikeSound() {
                    likeSound.currentTime = 0;
                    likeSound.play();
                }
                function playLoveSound() {
                    loveSound.currentTime =0;
                    loveSound.play()
                }
            };
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/detail.blade.php ENDPATH**/ ?>