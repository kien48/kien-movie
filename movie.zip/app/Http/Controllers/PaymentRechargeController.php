<?php

namespace App\Http\Controllers;

use App\Models\payment_recharge;
use Illuminate\Http\Request;

class PaymentRechargeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(payment_recharge $payment_recharge)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(payment_recharge $payment_recharge)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, payment_recharge $payment_recharge)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(payment_recharge $payment_recharge)
    {
        //
    }
}
