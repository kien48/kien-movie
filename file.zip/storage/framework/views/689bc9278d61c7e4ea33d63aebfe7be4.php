<?php $__env->startSection('title'); ?>
    Chi tiết phim
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div >
        <h1 class="text-center h3">Chi tiết phim</h1>
        <div class="card">
            <h3>Thông tin phim</h3>
            <div class="row">
                <div class="col-md-6">
                    <strong>ID:</strong> <?php echo e($modelMovie['id']); ?><br>
                    <strong>Tên:</strong> <?php echo e($modelMovie['ten']); ?><br>
                    <strong>Danh mục:</strong> <?php echo e($modelMovie['lists']['ten']); ?><br>
                    <strong>Ngôn ngữ:</strong> <?php echo e($modelMovie['ngon_ngu']); ?><br>
                    <strong>Số tập:</strong> <?php echo e($modelMovie['so_tap']); ?><br>
                    <strong>Chất lượng:</strong> <?php echo e($modelMovie['chat_luong']); ?><br>
                    <strong>Đạo diễn:</strong> <?php echo e($modelMovie['dao_dien']); ?><br>
                    <strong>Ảnh:</strong><br>
                    <img src="<?php echo e($modelMovie['anh']); ?>" alt="<?php echo e($modelMovie['ten']); ?>" class="img-thumbnail" width="100px"><br><br>
                </div>
                <div class="col-md-6">

                    <strong>Đường dẫn:</strong> <?php echo e($modelMovie['slug']); ?><br>
                    <strong>Mô tả:</strong><br>
                    <?php echo e($modelMovie['mo_ta']); ?><br><br>
                    <strong>Diễn viên:</strong> <?php echo e($modelMovie['dien_vien']); ?><br>
                    <strong>Năm phát hành:</strong> <?php echo e($modelMovie['nam_phat_hanh']); ?><br>
                    <strong>Quốc gia:</strong> <?php echo e($modelMovie['quoc_gia']); ?><br>
                    <strong>Trạng thái:</strong> <?php echo e($modelMovie['trang_thai']); ?><br>
                    <strong>Vip:</strong> <?php echo e($modelMovie['is_vip']); ?><br>
                    <strong>Ngày tạo:</strong> <?php echo e($modelMovie['created_at']); ?><br>
                </div>
            </div>
        </div>


        <div class="card">
            <h3>Thể loại</h3>
            <div class="row">
                <div class="col">
                    <?php $__currentLoopData = $modelCatelogue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-secondary"><?php echo e($item['ten']); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
        <div class="card">
            <h3>Tập phim</h3>
            <div class="row">
                <div class="col">
                    <?php $__currentLoopData = $modelEpisode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-secondary"><?php echo e($item['tap']); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/admin/movies/show.blade.php ENDPATH**/ ?>