<?php $__env->startSection('tilte'); ?>
    Tin mới nhất
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-post'); ?>
    <?php $__currentLoopData = $dataPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-3 post ms-2">
            <a href="<?php echo e(route('chitiet',$tin[0]->slug)); ?>" class="nav-link">
                <img src="<?php echo e(\Storage::url($tin[0]->anh)); ?>" alt="<?php echo e($tin[0]->tieu_de); ?>">
                <h4><?php echo e($tin[0]->tieu_de); ?></h4>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->startSection('title-post'); ?>
        Tag <?php echo e($end); ?>

    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blogs.blogs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/blogs/tag.blade.php ENDPATH**/ ?>