<?php $__env->startSection('title-post'); ?>
    Tin mới nhất
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-post'); ?>
    <?php $__currentLoopData = $postNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-3 post ms-2">
            <a href="<?php echo e(route('chitiet',$tin->slug)); ?>" class="nav-link">
                <img src="<?php echo e(\Storage::url($tin->anh)); ?>" alt="<?php echo e($tin->tieu_de); ?>">
                <h4><?php echo e($tin->tieu_de); ?></h4>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blogs.blogs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/blogs/new.blade.php ENDPATH**/ ?>