<?php $__env->startSection('title'); ?>
    Tin tức
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .header {
            text-align: center;
            padding: 30px 0;
        }

        .header h1 {
            font-size: 2.5rem;
            color: #ff3333;
        }

        .content {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .main-content {
            flex: 3;
        }

        .sidebar {
            flex: 1;
        }

        .post, .widget, .box {
            background-color: #2c2c2c;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            margin-bottom: 20px;
        }

        .post h4, .widget h3, .box h3 {
            font-size: 1.5rem;
            color: #ff3333;
            margin-bottom: 10px;
        }

        .post img {
            max-width: 100%;
            border-radius: 10px;
        }

        .widget ul, .box .categories, .box .tags {
            list-style: none;
            padding: 0;
        }

        .widget ul li, .box .categories a, .box .tags a {
            margin-bottom: 10px;
        }

        .widget ul li a, .box .categories a, .box .tags a {
            text-decoration: none;
            color: #fff;
            background-color: #ff3333;
            padding: 10px 20px;
            border-radius: 20px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .widget ul li a:hover, .box .categories a:hover, .box .tags a:hover {
            background-color: #cc0000;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <header class="header">
            <h1><?php echo $__env->yieldContent('title-post'); ?></h1>
        </header>
        <div class="content">
            <div class="main-content">
                <div class="row">
                    <?php echo $__env->yieldContent('content-post'); ?>
                </div>
            </div>
            <aside class="sidebar">
                <div class="widget">
                    <h3>Bài viết nổi bật</h3>
                    <ul>
                        <?php $__currentLoopData = $postHot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('chitiet',$post->slug)); ?>"><?php echo e($post->tieu_de); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </aside>
        </div>
        <?php if(Route::CurrentRouteName() == "blogs"): ?>
            <div class="box">
                <h3>Danh mục</h3>
                <div class="categories">
                    <?php $__currentLoopData = $danhMuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('danhMucBaiViet',[$item->id,$item->slug])); ?>"><?php echo e($item->ten); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="box">
                <h3>Tags</h3>
                <div class="tags">
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('tagBaiViet',[$item->id,$item->slug])); ?>"><?php echo e($item->ten); ?></a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/blogs/blogs.blade.php ENDPATH**/ ?>