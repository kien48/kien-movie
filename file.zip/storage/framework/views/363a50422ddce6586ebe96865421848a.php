<?php $__env->startSection('title'); ?>
    Nạp xu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 100px;">
        <div class="card mt-4">
            <div class="card-header">
                Nạp Xu
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('vnPay')); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="amount">Số Lượng Xu:</label>
                        <input type="number" name="coin" class="form-control" id="amount" ng-model="coin" ng-change="check()" placeholder="Nhập số lượng xu cần nạp">
                        <span ng-show="thongBao == false" class="text-danger h5">Phải lớn hơn 50000</span>
                    </div>
                    <button type="submit" name="redirect" class="btn btn-danger mt-3 btn-block" ng-disabled="disablePaymentButton">Thanh toán</button>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
        <script>
            viewFunction = ($scope,$http)=>     {
                    $scope.coin = '';
                    $scope.disablePaymentButton = true; // Ban đầu làm mờ nút
                    $scope.thongBao = true; // Ẩn thông báo ban đầu

                    $scope.check = function() {
                        if ($scope.coin < 10000) {
                            $scope.thongBao = false;
                            $scope.disablePaymentButton = true;
                        } else {
                            $scope.thongBao = true;
                            $scope.disablePaymentButton = false;
                        }
                    };
                }
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\movie\resources\views/auth/coins.blade.php ENDPATH**/ ?>